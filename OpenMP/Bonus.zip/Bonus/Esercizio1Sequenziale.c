#include <omp.h>	
#include <stdlib.h>	
#include <stdio.h>	
#include <math.h>	//per funzioni come cos, pow, sin, sqrt, M_PI

#define dim 10000

#define for_i for(unsigned int i = 0; i < dim; i++)
#define for_j for(unsigned int j = 0; j < dim; j++)
#define for_ij for_i for_j

int main() {

	double tempo = omp_get_wtime();
	
	double** matrice;
	matrice = (double**) malloc(dim* sizeof(double*));

	for_i
		matrice[i] = malloc(dim* sizeof(double));
		
	for_ij
		matrice[i][j] = 15 * cos(i) * sin(i) * sqrt(2*i) * M_PI * pow(j, 6);
	
	//Per controllare i valori della matrice 
/*	for_i
		for_j
			printf("matrice[%d][%d] = %f\n", i, j, matrice[i][j]);
		printf("\n");*/
	
	for_i
    	free(matrice[i]);
	free(matrice);
	
	printf("Tempo %f\n", omp_get_wtime() - tempo);

return 0;
}
