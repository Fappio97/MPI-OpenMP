#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

#define dim 10000000
#define NUM_OF_THREADS 4
#define for_i for(unsigned int i = 0; i < dim; ++i)

int main(){

	double tempo = omp_get_wtime();

	omp_set_num_threads(NUM_OF_THREADS);

	long Ncirc = 0;
	double pi_greco, x, y;
	double raggio = 1.0;

	#pragma omp parallel for private(x,y) reduction (+:Ncirc)
	for_i {
		x = (double) rand() / (RAND_MAX * 2.0 - 1.0);
		y = (double) rand() / (RAND_MAX * 2.0 - 1.0);
		if( (x * x + y * y) <= raggio * raggio) 
			Ncirc++;
	}
		
	pi_greco = 4.0 *((double) Ncirc / (double) dim);

//	printf("pi_greco = %f\n", pi);
	
	printf("Tempo : %f\n", omp_get_wtime() - tempo);

return 0;
}
