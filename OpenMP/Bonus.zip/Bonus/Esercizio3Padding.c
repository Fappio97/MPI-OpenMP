#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

#define dim 1000000000
#define NUM_OF_THREADS 4
#define PAD 8 //64byte
#define for_i for(unsigned int i = 0; i < NUM_OF_THREADS; ++i)


int main(){

	double tempo = omp_get_wtime();
	
	omp_set_num_threads(NUM_OF_THREADS);

	int tid;
	double x, pi = 0.0, sum = 0.0;
	double volte = 1.0 / (double) dim;

	double** sums = (double**) malloc(NUM_OF_THREADS* sizeof(double*));
	for_i
		sums[i] = (double*) malloc(PAD* sizeof(double));

	#pragma omp parallel private(x, tid) shared(sums)
	{
		int threads = omp_get_num_threads();
		tid = omp_get_thread_num();

		sums[tid][0] = 0.0;

		for(unsigned int i = tid; i < dim; i += threads){
			x = (i + 0.5) * volte;
			sums[tid][0] += 4.0 / (1.0+x*x);
		}
	}

	for_i
		pi += volte * sums[i][0];


	for_i
		free(sums[i]);
	free(sums);

	printf("Tempo : %f\n", omp_get_wtime() - tempo);
	
return 0;
}
