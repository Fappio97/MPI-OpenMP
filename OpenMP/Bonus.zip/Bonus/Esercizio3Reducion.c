#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

#define SIZE 1000000000
#define NUM_OF_THREADS 4


int main(){

	omp_set_num_threads(NUM_OF_THREADS);

	double pi_greco=0.0; 
	double step = 1.0/(double) SIZE;

	double time = omp_get_wtime();

		#pragma omp parallel reduction(+:pi_greco)
		{
			int i, id;
			double x, sum = 0.0;
			id = omp_get_thread_num();
			
			for(i = id; i < SIZE; i += NUM_OF_THREADS){
				x = (i + 0.5) * step;
				sum += 4.0/(1.0 + (x * x));
			}
		
			sum *= step;
			
			pi_greco += sum;
		}
	printf("Tempo: %f\n\n", omp_get_wtime() - tempo);


return 0;
}
