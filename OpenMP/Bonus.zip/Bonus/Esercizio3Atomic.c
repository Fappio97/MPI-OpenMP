#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

#define dim 1000000000
#define NUM_OF_THREADS 4


int main(){
	
	omp_set_num_threads(NUM_OF_THREADS);

	double pi_greco = 0.0;
	double volte = 1.0/(double) dim;
	int threads;

	double tempo = omp_get_wtime();

	#pragma omp parallel
	{
		double x, somma = 0.0;
		int id = omp_get_thread_num();
		int threads = omp_get_num_threads();
			
		if(id == 0) 
			threads = omp_get_num_threads();

		for(unsigned int i = id; i < dim; i += threads) {
			x = (i + 0.5) * volte;
			somma += 4.0 / (1.0 + (x * x));
		}	
		#pragma omp atomic
			pi_greco += somma;			
	}
	pi_greco /= dim;

	printf("Tempo : %f\n", omp_get_wtime() - tempo);	
	
return 0;
}
