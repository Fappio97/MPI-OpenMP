#include <omp.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <math.h>
#include <limits.h>

#define dim 500000000
#define for_i for(unsigned int i = 0; i < dim; ++i)

int main() {

	srand(time(NULL));
	
	double time = omp_get_wtime();
	int* A = malloc(dim* sizeof(int));
	int* B = malloc(dim* sizeof(int));
	int* C = malloc(dim* sizeof(int));
	
	for_i {
		A[i] = random()%10;	//creo un numero casuale tra 0 e 9
		B[i] = random()%10;
		C[i] = A[i] + B[i];	//imbarazzantemente parallelo perché ogni thread lavora su una parte indipendente
	}

/*	Verifica stampa numeri
	for_i {
		printf("A[%d] = %d\n", i, A[i]);
		printf("B[%d] = %d\n", i, B[i]);
	}
	
	printf("\n");
	for_i {
		printf("C[%d] = %d\n", i, C[i]);
	}*/	
	
	int max = INT_MIN;
	for_i {
		if(max < C[i])
			max = C[i];
	}
	
	free(A);
	free(B);
	free(C);
	
	printf("Valore massimo nel vettore C = %d\n", max);
	printf("Tempo %f\n", omp_get_wtime() - time);
		
return 0;
}
