#include <omp.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <limits.h>

#define dim 200000000
#define NUM_OF_THREADS 4
#define for_i for(unsigned int i = 0; i < dim; ++i)

int main() {
	
	double time = omp_get_wtime();
	int* A = malloc(dim* sizeof(int));
	int* B = malloc(dim* sizeof(int));
	int* C = malloc(dim* sizeof(int));
	
	omp_set_num_threads(NUM_OF_THREADS);
	
	int max = INT_MIN;
	
	unsigned int seed;
	
	for_i {
		A[i] = rand_r(&seed) % 10;	//creo un numero casuale tra 0 e 9
		B[i] = rand_r(&seed) % 10;
	}
	
	#pragma omp parallel for
	for_i 
		C[i] = A[i] + B[i];

	/*	Verifica stampa numeri
		for_i {
			printf("A[%d] = %d\n", i, A[i]);
			printf("B[%d] = %d\n", i, B[i]);
		}
		
		printf("\n");
		for_i {
			printf("C[%d] = %d\n", i, C[i]);
		}*/	
	
	#pragma omp parallel shared(max)
	{
		int max_locale;
		#pragma omp for nowait
		for_i {
			if(max_locale < C[i])
				max_locale = C[i];
		}
		#pragma omp critical
		{
			if(max_locale > max)
				max = max_locale;
		}
	}
	
	free(A);
	free(B);
	free(C);
	
	printf("Valore massimo nel vettore C = %d\n", max);
	printf("Tempo %f\n", omp_get_wtime() - time);
		
return 0;
}
