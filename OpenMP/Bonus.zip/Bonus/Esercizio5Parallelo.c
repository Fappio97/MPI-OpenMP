#include <omp.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <unistd.h>

#define righe 40
#define colonne 40
#define NUM_OF_THREADS 2
#define for_i for(unsigned int i = 0; i < righe; ++i)
#define for_j for(unsigned int j = 0; j < colonne; ++j)

void creaMatrice(char** matrice) {
	#pragma omp parallel for
	for_i
		matrice[i] = (char*) malloc(colonne* sizeof(char));
}

void deallocaMatrice(char** matrice ) {
	#pragma omp parallel for
	for_i
		free(matrice[i]);
	free(matrice);
}

void matriceRandom(char** matrice) {
	unsigned int seed;
	#pragma omp parallel for
	for_i {
		for_j {
			//gestisco la probabilità con cui viene creata una cella viva o mota, in questo caso è pari al 25%
			if((rand_r(&seed) % 5) == 0)		
				matrice[i][j] = '*';	// il carattere * corrisponde a cella viva
			else
				matrice[i][j] = ' ';    // il carattere spazio corrisponde a cella morta
		}
	} 
}

void copiaMatrice(char** matrice1, char** matrice2) {
	#pragma omp parallel for
	for_i
		for_j
			matrice1[i][j] = matrice2[i][j];
} 

void stampaMatrice(char** matrice) {
	printf("\033[H");
	#pragma omp parallel for
	for_i {
		for_j {
			printf("%c", matrice[i][j]);
		}
		printf("\033[E");
	}
}

bool uguali(char** matrice1, char** matrice2) {
	bool uguali = true;
	#pragma omp parallel shared(uguali)
	{
		#pragma omp for
		for_i {
			if(!uguali) {
				#pragma omp cancel for
			}
			for_j {
				if(matrice1[i][j] != matrice2[i][j]) {
					uguali = false;
					#pragma omp cancel for
				}
			}
		}
	}
	return uguali;
}

int calcolaVive(char** matrice1, int i, int j) {
	int conta = 0;
	int precedenteColonna, successivaColonna;
	int precedenteRiga, successivaRiga;
	
	if(i-1 < 0)
		precedenteRiga = righe-1;
	else
		precedenteRiga = i-1;
		
	if(i+1 >= righe)
		successivaRiga = 0;
	else
		successivaRiga = i+1;
		
	if(j-1 < 0)
		precedenteColonna = colonne-1;
	else
		precedenteColonna = j-1;
		
	if(j+1 >= colonne)
		successivaColonna = 0;
	else
		successivaColonna = j+1;		
		
	if(matrice1[precedenteRiga][precedenteColonna] == '*')
		conta++;
	if(matrice1[precedenteRiga][j] == '*')
		conta++;
	if(matrice1[precedenteRiga][successivaColonna] == '*')
		conta++;
	if(matrice1[i][precedenteColonna] == '*')
		conta++;
	if(matrice1[i][successivaColonna] == '*')
		conta++;
	if(matrice1[successivaRiga][precedenteColonna] == '*')
		conta++;
	if(matrice1[successivaRiga][j] == '*')
		conta++;
	if(matrice1[successivaRiga][successivaColonna] == '*')
		conta++;
		
	return conta;
}

void gioco(char** matrice1, char** matrice2) {
	#pragma omp parallel for
	for_i {
		for_j {
			if(matrice1[i][j] == ' ' && calcolaVive(matrice1, i, j) == 3)
				matrice2[i][j] = '*';
			else if(matrice1[i][j] == ' ')
				matrice2[i][j] = ' ';
			else if(matrice1[i][j] == '*' && ( calcolaVive(matrice1, i, j) == 2 || calcolaVive(matrice1, i, j) == 3 ) )
				matrice2[i][j] = '*';
			else
				matrice2[i][j] = ' ';
		}
	}
}

int main() {

	double tempo = omp_get_wtime();
	
	omp_set_num_threads(NUM_OF_THREADS);

	char** matrice1 = (char**)malloc(righe* sizeof(char*));
	char** matrice2 = (char**)malloc(righe* sizeof(char*));

	creaMatrice(matrice1);	
	creaMatrice(matrice2);
	matriceRandom(matrice1);
	copiaMatrice(matrice2, matrice1);	

//	#pragma omp parallel for
//	for(int i = 0; i < 1000; ++i) {
	do {
		stampaMatrice(matrice1);
		copiaMatrice(matrice1, matrice2);	
		gioco(matrice1, matrice2);		
		sleep(1);
	} while(!uguali(matrice1, matrice2));
//	}
	
	deallocaMatrice(matrice1);
	deallocaMatrice(matrice2);
	
	printf("Tempo %f\n", omp_get_wtime() - tempo);
	
return 0;
}
