#include <omp.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#define dim 10000000
#define NUM_OF_THREADS 4
#define for_i for(unsigned int i = 0; i < dim; ++i) 

int main() {

	double tempo = omp_get_wtime();
	
	
	int* vettore = malloc(dim* sizeof(int));
	
	int elemento = 0;

/*	int elemento;
	printf("Inserire l'elemento da cercare ");
	scanf("%d", &elemento);*/
	
/*	if(!omp_get_cancellation())	//per controllare se cancellation è abilitato
		printf("NO\n");
	else
		printf("SI\n");*/
	
	omp_set_num_threads(NUM_OF_THREADS);
	
	bool trovato = false;
	
	unsigned int seed;
	
	for_i
		vettore[i] = rand_r(&seed) % 20;
		
	#pragma omp parallel
	{	
		#pragma omp for
		for_i {
			if(trovato) {
				#pragma omp cancel for
			}
			if(elemento == vettore[i]) {
				#pragma omp critical
					trovato = true;
			}
		}
		if(trovato) {
			#pragma omp single
			printf("Trovato\n");
			#pragma omp cancel parallel
		}
	}
	
	free(vettore);
	
	printf("Tempo = %f\n", omp_get_wtime() - tempo);
	
return 0;
}
