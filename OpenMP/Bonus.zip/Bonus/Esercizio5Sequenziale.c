#include <omp.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#define righe 100
#define colonne 100
#define for_i for(unsigned int i = 0; i < righe; ++i)
#define for_j for(unsigned int j = 0; j < colonne; ++j)

void creaMatrice(char** matrice) {
	for_i
		matrice[i] = (char*) malloc(colonne* sizeof(char));
}

void deallocaMatrice(char** matrice ) {
	for_i
		free(matrice[i]);
	free(matrice);
}

void matriceRandom(char** matrice) {
	unsigned int seed;
	for_i {
		for_j {
			//gestisco la probabilità con cui viene creata una cella viva o mota, in questo caso è pari al 25%
			if((rand_r(&seed) % 5) == 0)		
				matrice[i][j] = '*';	// il carattere * corrisponde a cella viva
			else
				matrice[i][j] = ' ';    // il carattere spazio corrisponde a cella morta
		}
	} 
}

void copiaMatrice(char** matrice1, char** matrice2) {
	for_i
		for_j
			matrice1[i][j] = matrice2[i][j];
} 

void stampaMatrice(char** matrice) {
	printf("\033[H");
	for_i {
		for_j {
			printf("%c", matrice[i][j]);
		}
		printf("\033[E");
	}
}

bool uguali(char** matrice1, char** matrice2) {
	bool uguali = true;
	for_i {			
		for_j {
			if(!uguali) {
				break;
			}
			if(matrice1[i][j] != matrice2[i][j]) {
				uguali = false;	
			}	
		}
		if(!uguali) {
			break;
		}
	}
	return uguali;
}

int calcolaVive(char** matrice1, int i, int j) {
	int conta = 0;
	int precedenteColonna, successivaColonna;
	int precedenteRiga, successivaRiga;
	
	if(i-1 < 0)
		precedenteRiga = righe-1;
	else
		precedenteRiga = i-1;
		
	if(i+1 >= righe)
		successivaRiga = 0;
	else
		successivaRiga = i+1;
		
	if(j-1 < 0)
		precedenteColonna = colonne-1;
	else
		precedenteColonna = j-1;
		
	if(j+1 >= colonne)
		successivaColonna = 0;
	else
		successivaColonna = j+1;		
		
	if(matrice1[precedenteRiga][precedenteColonna] == '*')
		conta++;
	if(matrice1[precedenteRiga][j] == '*')
		conta++;
	if(matrice1[precedenteRiga][successivaColonna] == '*')
		conta++;
	if(matrice1[i][precedenteColonna] == '*')
		conta++;
	if(matrice1[i][successivaColonna] == '*')
		conta++;
	if(matrice1[successivaRiga][precedenteColonna] == '*')
		conta++;
	if(matrice1[successivaRiga][j] == '*')
		conta++;
	if(matrice1[successivaRiga][successivaColonna] == '*')
		conta++;
		
	return conta;
}

void gioco(char** matrice1, char** matrice2) {
	for_i {
		for_j {
			if(matrice1[i][j] == ' ' && calcolaVive(matrice1, i, j) == 3)
				matrice2[i][j] = '*';
			else if(matrice1[i][j] == ' ')
				matrice2[i][j] = ' ';
			else if(matrice1[i][j] == '*' && ( calcolaVive(matrice1, i, j) == 2 || calcolaVive(matrice1, i, j) == 3 ) )
				matrice2[i][j] = '*';
			else
				matrice2[i][j] = ' ';
		}
	}
}

int main() {

	double tempo = omp_get_wtime();

	char** matrice1 = (char**)malloc(righe* sizeof(char*));
	char** matrice2 = (char**)malloc(righe* sizeof(char*));

	creaMatrice(matrice1);	
	creaMatrice(matrice2);
	matriceRandom(matrice1);
	copiaMatrice(matrice2, matrice1);	

	for(int i = 0; i < 10; ++i) {
		stampaMatrice(matrice1);
		copiaMatrice(matrice1, matrice2);	
		gioco(matrice1, matrice2);		
	}
	
	deallocaMatrice(matrice1);
	deallocaMatrice(matrice2);

	printf("Tempo %f\n", omp_get_wtime() - tempo);
	
return 0;
}
