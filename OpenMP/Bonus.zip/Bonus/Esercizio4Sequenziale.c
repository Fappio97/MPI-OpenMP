#include <omp.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>

#define dim 1000000000
#define for_i for(unsigned int i = 0; i < dim; ++i) 

int main() {
	
	double tempo = omp_get_wtime();
	
	int* vettore = malloc(dim* sizeof(int));
	
	int elemento = 0;
	
/*	int elemento;
	printf("Inserire l'elemento da cercare ");
	scanf("%d", &elemento);*/
	
/*	if(!omp_get_cancellation())
	printf("NO\n");*/
	
	unsigned int seed;
	
	for_i
		vettore[i] = rand_r(&seed) % 20;
		
	bool trovato = false;
	for_i {
		if(elemento == vettore[i]) {
			trovato = true;
		}
	}
	if(trovato)
		printf("Trovato\n");
	
	free(vettore);
	
	printf("Tempo = %f\n", omp_get_wtime() - tempo);
	
return 0;
}
